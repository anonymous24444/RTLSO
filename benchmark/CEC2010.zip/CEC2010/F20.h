#ifndef _F20_H
#define _F20_H

#include "Benchmarks.h"

class F20:public Benchmarks{
protected:
public:
	F20();
	double compute(double* x) ;
	double compute(std::vector<double> x) ;
	~F20();
};

#endif

